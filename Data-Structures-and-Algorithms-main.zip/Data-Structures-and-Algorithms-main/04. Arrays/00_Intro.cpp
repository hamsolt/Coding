#include<bits/stdc++.h>
using namespace std;

int main()
{
    /*
    
    Array Advantages :

    1.Contigous memory
    2.Random access
    3.Cache friendliness

    Types of arrays :

    1.fixed size arrays , eg: int arr[100]
    2.dynamic size arrays , eg: vector<int> v
    
    */
}
#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*

	Inbuilt sort function features :

	1. worst and average time comp. O(nlogn)
	2. uses Intro-Sort (hybrid of heapsort , quicksort and insertion sort)
	
	*/

	return 0;
}
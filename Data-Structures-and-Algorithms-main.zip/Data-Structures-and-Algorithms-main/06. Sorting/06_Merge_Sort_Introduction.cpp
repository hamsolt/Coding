#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*
	
	Features :

	1.divide and conquer algorithm

	2.3steps :
		a.divide
		b.sort
		c.merge
	
	3.stable algorithm
	
	4.Time comp. O(n*logn)
	
	5.Space comp. O(n)
	
	6.For arrays : Quicksort is perform better
	than merge sort
	
	*/

	return 0;
}
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int x=3,y=6;

    cout<<(x&y)<<endl;//and
    cout<<(x|y)<<endl;//or
    cout<<(x^y)<<endl;//xor    
    
    return 0;
}
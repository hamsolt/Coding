#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*
	Time Complexity Order :

	c < log(logn) < logn < n^(1/3) < n^(1/2) < n < n(logn) < n^2 < n^3 < 2^n < n^n

	Compare Time Complexity :

	let f(n) and g(n) be two function such that { f(n),g(n),n >=0 }

	if f(n)/g(n) equals 0 for n->INFINITY then g(n) is growing faster than f(n)
	*/
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	cin>>s;

	/*
	if you give input : "parth" then it will print "parth"
	if you give input : "parth garg" then only "parth" will be printed

	because cin when sees space it stops reading the character 
	*/

	cout<<s;
	return 0;
}
#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*
	
	ASCII Values :

	'a' to 'z' : 97 - 122

	'A' to 'Z' : 65 - 90

	'0' to '9' : 48 - 57
	
	*/

	return 0;
}
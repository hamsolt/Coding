#include<bits/stdc++.h>
using namespace std;

int main()
{
	char ch='A';

	for(int i=0;i<26;i++)
	{
		cout<<ch<<" "<<int(ch)<<endl;
		ch++;
	}

	return 0;
}